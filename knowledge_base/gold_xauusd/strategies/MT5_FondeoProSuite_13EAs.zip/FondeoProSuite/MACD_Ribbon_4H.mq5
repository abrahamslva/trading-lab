//+------------------------------------------------------------------+
//|  MACD_Ribbon_4H.mq5                                             |
//|  MACD Bands + Ribbon V6 FONDEO PRO  |  Temporalidad: 4 Horas    |
//|  Magic: 300003  |  Riesgo: 0.166% por trade                     |
//+------------------------------------------------------------------+
#property copyright "Fondeo Pro Suite"
#property version   "1.00"
#property strict

#define MAGIC_NUMBER   300003
#define EA_NAME        "MACD Ribbon 4H"

#define RISK_PERCENT   0.00166
#define MAX_LOSS_USD   170.0

//==========================================================================
//  PARÁMETROS EXTERNOS
//==========================================================================
input group "=== MACD ==="
input int    FastLen       = 21;       // MACD Fast EMA
input int    SlowLen       = 35;       // MACD Slow EMA
input int    SignalLen     = 14;       // MACD Signal EMA

input group "=== Ribbon ==="
input int    RibbonLen     = 14;       // Ribbon Length
input int    RibbonSmooth  = 6;        // Ribbon Smoothing

input group "=== Riesgo ==="
input int    SwingLen      = 10;       // Velas para SL (swing low)
input double Leverage      = 25.0;      // Apalancamiento (1-100)

//==========================================================================
//  VARIABLES GLOBALES
//==========================================================================
int      g_handleFastEMA = INVALID_HANDLE;
int      g_handleSlowEMA = INVALID_HANDLE;
int      g_handleATR     = INVALID_HANDLE;
int      g_handleRibbon  = INVALID_HANDLE;
int      g_handleRibbonS = INVALID_HANDLE;

int      g_dailyLosses    = 0;
bool     g_tradingAllowed = true;
datetime g_lastDay        = 0;

//==========================================================================
//  GESTIÓN DE RIESGO
//==========================================================================
double CalcLots(double slPriceDistance)
{
   if(slPriceDistance <= 0) return 0;
   double equity  = AccountInfoDouble(ACCOUNT_EQUITY);
   double riskAmt = equity * RISK_PERCENT * Leverage;
   if(riskAmt > MAX_LOSS_USD) riskAmt = MAX_LOSS_USD;

   double tickVal = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double tickSz  = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
   if(tickVal <= 0 || tickSz <= 0) return 0;

   double lots = riskAmt / (slPriceDistance / tickSz * tickVal);
   double minL = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double maxL = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
   double step = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
   return MathMax(minL, MathMin(maxL, MathRound(lots/step)*step));
}

//==========================================================================
//  3-STRIKES
//==========================================================================
void UpdateDailyLosses()
{
   MqlDateTime dt; TimeToStruct(TimeCurrent(), dt);
   datetime today = StringToTime(StringFormat("%04d.%02d.%02d 00:00:00",
                                               dt.year, dt.mon, dt.day));
   if(today != g_lastDay) { g_dailyLosses=0; g_tradingAllowed=true; g_lastDay=today; }

   HistorySelect(today, TimeCurrent());
   int losses = 0;
   for(int i=0; i<HistoryDealsTotal(); i++)
   {
      ulong tk = HistoryDealGetTicket(i);
      if(HistoryDealGetInteger(tk,DEAL_MAGIC) != MAGIC_NUMBER) continue;
      if(HistoryDealGetInteger(tk,DEAL_ENTRY) != DEAL_ENTRY_OUT) continue;
      double pnl = HistoryDealGetDouble(tk,DEAL_PROFIT)
                 + HistoryDealGetDouble(tk,DEAL_SWAP)
                 + HistoryDealGetDouble(tk,DEAL_COMMISSION);
      if(pnl < 0) losses++;
   }
   g_dailyLosses = losses;
}

void ClosePosition(ulong ticket)
{
   MqlTradeRequest req={}; MqlTradeResult res={};
   req.action=TRADE_ACTION_DEAL; req.symbol=_Symbol;
   req.volume=PositionGetDouble(POSITION_VOLUME); req.type=ORDER_TYPE_SELL;
   req.price=SymbolInfoDouble(_Symbol,SYMBOL_BID);
   req.deviation=30; req.magic=MAGIC_NUMBER; req.position=ticket;
   OrderSend(req,res);
}

void SetSLTP(ulong ticket, double sl, double tp)
{
   MqlTradeRequest req={}; MqlTradeResult res={};
   req.action=TRADE_ACTION_SLTP; req.symbol=_Symbol;
   req.sl=sl; req.tp=tp; req.position=ticket;
   OrderSend(req,res);
}

void ApplyStrikesRules()
{
   if(g_dailyLosses >= 3)
   {
      g_tradingAllowed=false;
      for(int i=PositionsTotal()-1;i>=0;i--)
         if(PositionGetSymbol(i)==_Symbol && PositionGetInteger(POSITION_MAGIC)==MAGIC_NUMBER)
            ClosePosition(PositionGetInteger(POSITION_TICKET));
      return;
   }
   if(g_dailyLosses == 2)
   {
      g_tradingAllowed=false;
      for(int i=PositionsTotal()-1;i>=0;i--)
      {
         if(PositionGetSymbol(i)!=_Symbol || PositionGetInteger(POSITION_MAGIC)!=MAGIC_NUMBER) continue;
         ulong  tk     = PositionGetInteger(POSITION_TICKET);
         double profit = PositionGetDouble(POSITION_PROFIT);
         double entry  = PositionGetDouble(POSITION_PRICE_OPEN);
         double tp     = PositionGetDouble(POSITION_TP);
         if(profit >= 0) SetSLTP(tk, entry, tp);  // BE
         else            ClosePosition(tk);
      }
   }
}

//==========================================================================
//  DASHBOARD
//==========================================================================
void UpdateDashboard()
{
   double equity  = AccountInfoDouble(ACCOUNT_EQUITY);
   double riskUsd = MathMin(equity * RISK_PERCENT * Leverage, MAX_LOSS_USD);
   string status  = g_tradingAllowed ? "ACTIVO" : "BLOQUEADO (Drawdown)";
   Comment(StringFormat(
      "╔══════════════════════════════╗\n"
      "║  %s - %s\n"
      "║  Estado Bot : %s\n"
      "║  Perdidas Hoy: %d / 3\n"
      "║  Riesgo/Trade: $%.2f USD\n"
      "║  Apalancamiento: x%.1f\n"
      "║  Equity: $%.2f USD\n"
      "╚══════════════════════════════╝",
      EA_NAME, _Symbol, status,
      g_dailyLosses, riskUsd, Leverage, equity));
}

//==========================================================================
//  EMA MANUAL (para MACD sobre close)
//==========================================================================
double ManualEMA(int period, int shift=0)
{
   // Calcula EMA usando iMA handle-free approach: iMA del símbolo
   int h = iMA(_Symbol, PERIOD_CURRENT, period, 0, MODE_EMA, PRICE_CLOSE);
   double buf[1];
   CopyBuffer(h, 0, shift, 1, buf);
   IndicatorRelease(h);
   return buf[0];
}

//==========================================================================
//  EVENTOS PRINCIPALES
//==========================================================================
int OnInit()
{
   g_handleFastEMA = iMA(_Symbol, PERIOD_CURRENT, FastLen,   0, MODE_EMA, PRICE_CLOSE);
   g_handleSlowEMA = iMA(_Symbol, PERIOD_CURRENT, SlowLen,   0, MODE_EMA, PRICE_CLOSE);
   g_handleRibbon  = iMA(_Symbol, PERIOD_CURRENT, RibbonLen, 0, MODE_EMA, PRICE_CLOSE);
   g_handleRibbonS = iMA(_Symbol, PERIOD_CURRENT, RibbonLen, 0, MODE_SMA, PRICE_CLOSE);
   // Para RibbonSmooth (SMA del EMA), necesitamos calcular manualmente
   g_handleATR     = iATR(_Symbol, PERIOD_CURRENT, 14);

   if(g_handleFastEMA==INVALID_HANDLE || g_handleSlowEMA==INVALID_HANDLE ||
      g_handleATR==INVALID_HANDLE || g_handleRibbon==INVALID_HANDLE)
   { Print(EA_NAME," Error handles"); return INIT_FAILED; }

   Print(EA_NAME, " inicializado. Magic=", MAGIC_NUMBER);
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   IndicatorRelease(g_handleFastEMA);
   IndicatorRelease(g_handleSlowEMA);
   IndicatorRelease(g_handleATR);
   IndicatorRelease(g_handleRibbon);
   IndicatorRelease(g_handleRibbonS);
   Comment("");
}

void OnTick()
{
   static datetime lastBar = 0;
   datetime curBar = iTime(_Symbol, PERIOD_CURRENT, 0);
   if(curBar == lastBar) { UpdateDashboard(); return; }
   lastBar = curBar;

   UpdateDailyLosses();
   ApplyStrikesRules();

   //--- Copiar EMAs (necesitamos bar[1] y bar[2] para crossover)
   double fastArr[3], slowArr[3], atrArr[3], ribbonArr[3];
   if(CopyBuffer(g_handleFastEMA, 0, 1, 3, fastArr) < 3) return;
   if(CopyBuffer(g_handleSlowEMA, 0, 1, 3, slowArr) < 3) return;
   if(CopyBuffer(g_handleATR,     0, 1, 3, atrArr)  < 3) return;
   if(CopyBuffer(g_handleRibbon,  0, 1, 3, ribbonArr)< 3) return;

   // MACD lines: bar[0]=más reciente copiada = bar[1] del chart
   double macd1  = fastArr[0] - slowArr[0];  // bar[1]
   double macd2  = fastArr[1] - slowArr[1];  // bar[2]

   // Signal = EMA(MACD, SignalLen) — aproximamos con handle temporal
   // Usamos SMA simple como aproximación robusta para evitar handle extra
   double macd_sum = 0;
   double fastTmp[3+14], slowTmp[3+14];
   int needed = SignalLen + 2;
   ArrayResize(fastTmp, needed); ArrayResize(slowTmp, needed);
   if(CopyBuffer(g_handleFastEMA, 0, 1, needed, fastTmp) < needed) return;
   if(CopyBuffer(g_handleSlowEMA, 0, 1, needed, slowTmp) < needed) return;
   // Calcular EMA de MACD manualmente
   double signal2 = (fastTmp[needed-1] - slowTmp[needed-1]);
   double kSig = 2.0 / (SignalLen + 1);
   for(int i = needed-2; i >= 0; i--)
   {
      double m = fastTmp[i] - slowTmp[i];
      signal2  = m * kSig + signal2 * (1 - kSig);
   }
   // signal2 ahora es la señal EMA en bar[1]
   // Para bar[2]:
   double signal_prev = (fastTmp[needed-1] - slowTmp[needed-1]);
   kSig = 2.0 / (SignalLen + 1);
   for(int i = needed-2; i >= 1; i--)
   {
      double m   = fastTmp[i] - slowTmp[i];
      signal_prev = m * kSig + signal_prev * (1 - kSig);
   }

   //--- Bull dot: crossover(macd, signal)
   bool bull_dot = (macd1 >= signal2) && (macd2 < signal_prev);

   //--- Ribbon: tr_base = EMA(close, RibbonLen), tr_smoothed = SMA(EMA, RibbonSmooth)
   double tr_base1  = ribbonArr[0];
   double smooth_sum = 0;
   double ribbonTmp[20];
   if(CopyBuffer(g_handleRibbon, 0, 1, RibbonSmooth, ribbonTmp) >= RibbonSmooth)
   {
      for(int i=0; i<RibbonSmooth; i++) smooth_sum += ribbonTmp[i];
   }
   double tr_smoothed1 = smooth_sum / RibbonSmooth;
   bool ribbon_green = tr_base1 > tr_smoothed1;

   //--- Estructura: close > close[1]
   bool estructura = iClose(_Symbol,PERIOD_CURRENT,1) > iClose(_Symbol,PERIOD_CURRENT,2);

   //--- Filtro volatilidad: ATR > SMA(ATR,20)
   double atrTmp[22];
   CopyBuffer(g_handleATR, 0, 1, 22, atrTmp);
   double atr_sma = 0;
   for(int i=0; i<20; i++) atr_sma += atrTmp[i];
   atr_sma /= 20;
   bool filtro_vol = atrArr[0] > atr_sma;

   //--- Señal de compra
   bool compra = bull_dot && ribbon_green && estructura && filtro_vol;

   //--- Ejecución
   if(compra && g_tradingAllowed && PositionsTotal() == 0)
   {
      // Cerrar posición anterior si existe
      for(int i=PositionsTotal()-1;i>=0;i--)
         if(PositionGetSymbol(i)==_Symbol && PositionGetInteger(POSITION_MAGIC)==MAGIC_NUMBER)
            ClosePosition(PositionGetInteger(POSITION_TICKET));

      double ask    = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
      // SL = lowest(low, SwingLen)
      double sl_val = DBL_MAX;
      for(int i=1; i<=SwingLen; i++) sl_val = MathMin(sl_val, iLow(_Symbol,PERIOD_CURRENT,i));

      double riesgo_precio = ask - sl_val;
      if(riesgo_precio <= 0) riesgo_precio = atrArr[0];

      // RR dinámico según ATR
      double atr50_sum = 0;
      double atrTmp50[52];
      CopyBuffer(g_handleATR, 0, 1, 52, atrTmp50);
      for(int i=0; i<50; i++) atr50_sum += atrTmp50[i];
      double atr50 = atr50_sum / 50.0;
      double rr    = atrArr[0] > atr50 ? 1.8 : 1.3;
      double tp    = ask + riesgo_precio * rr;

      double lots  = CalcLots(riesgo_precio);
      if(lots <= 0) { UpdateDashboard(); return; }

      MqlTradeRequest req={}; MqlTradeResult res={};
      req.action=TRADE_ACTION_DEAL; req.symbol=_Symbol; req.volume=lots;
      req.type=ORDER_TYPE_BUY; req.price=ask;
      req.sl=NormalizeDouble(sl_val,_Digits);
      req.tp=NormalizeDouble(tp,_Digits);
      req.deviation=30; req.magic=MAGIC_NUMBER; req.comment=EA_NAME;
      if(!OrderSend(req,res)) Print(EA_NAME," Error: ",GetLastError());
   }

   //--- Break Even: si precio >= entry + riesgo inicial
   for(int i=PositionsTotal()-1;i>=0;i--)
   {
      if(PositionGetSymbol(i)!=_Symbol || PositionGetInteger(POSITION_MAGIC)!=MAGIC_NUMBER) continue;
      ulong  tk    = PositionGetInteger(POSITION_TICKET);
      double entry = PositionGetDouble(POSITION_PRICE_OPEN);
      double csl   = PositionGetDouble(POSITION_SL);
      double ctp   = PositionGetDouble(POSITION_TP);
      double riesgo_inicial = entry - csl;
      double bid   = SymbolInfoDouble(_Symbol, SYMBOL_BID);
      if(bid >= entry + riesgo_inicial && csl < entry)
         SetSLTP(tk, entry, ctp);  // Mover SL a BE
   }

   UpdateDashboard();
}
//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
//|  VMC_B_LongOnly_4H.mq5                                          |
//|  VuManChu Cipher B - Long Only  |  Temporalidad: 1 Hora         |
//|  Magic: 100004  |  Riesgo: 0.166% por trade                     |
//+------------------------------------------------------------------+
#property copyright "Fondeo Pro Suite"
#property version   "1.00"
#property strict

//--- Magic Number único para esta instancia
#define MAGIC_NUMBER   100004
#define EA_NAME        "VMC LongOnly 4H"

//--- Constantes de riesgo institucional
#define RISK_PERCENT   0.00166    // 0.166% fijo
#define MAX_LOSS_USD   170.0      // Techo por trade
#define MAX_DAILY_USD  510.0      // 3 x $170

//==========================================================================
//  PARÁMETROS EXTERNOS
//==========================================================================
input group "=== WaveTrend ==="
input int    WtChannelLen  = 9;        // WT Channel Length
input int    WtAverageLen  = 12;       // WT Average Length
input int    WtMALen       = 3;        // WT MA Length
input int    OsLevel       = -53;      // Oversold Level 1
input int    OsLevel2      = -60;      // Oversold Level 2

input group "=== Estrategia ==="
input double SL_Pct        = 1.0;      // SL % desde entrada
input double TP_Pct        = 2.0;      // TP % desde entrada

input group "=== Riesgo ==="
input double Leverage      = 1.0;      // Apalancamiento (1-100)

//==========================================================================
//  VARIABLES GLOBALES
//==========================================================================
int      g_dailyLosses   = 0;
bool     g_tradingAllowed = true;
datetime g_lastDay        = 0;

double   g_wt1[], g_wt2[];
double   g_esa[], g_de[], g_ci[];
int      g_bufSize = 200;

//==========================================================================
//  FUNCIONES DE INDICADOR - WaveTrend
//==========================================================================
double HLC3(int shift) { return (iHigh(_Symbol,PERIOD_CURRENT,shift) +
                                  iLow (_Symbol,PERIOD_CURRENT,shift) +
                                  iClose(_Symbol,PERIOD_CURRENT,shift)) / 3.0; }

//--- EMA incremental sobre array
void CalcWaveTrend(double &wt1Out[], double &wt2Out[], int size)
{
   if(size < WtChannelLen + WtAverageLen + WtMALen + 5) return;

   double k_ch = 2.0 / (WtChannelLen + 1);
   double k_av = 2.0 / (WtAverageLen  + 1);

   ArrayResize(g_esa, size);
   ArrayResize(g_de,  size);
   ArrayResize(g_ci,  size);
   ArrayResize(wt1Out, size);
   ArrayResize(wt2Out, size);

   // Seed
   g_esa[size-1] = HLC3(size-1);
   g_de [size-1] = 0;
   g_ci [size-1] = 0;
   wt1Out[size-1] = 0;

   for(int i = size-2; i >= 0; i--)
   {
      double src = HLC3(i);
      g_esa[i]  = src * k_ch + g_esa[i+1] * (1 - k_ch);
      g_de[i]   = MathAbs(src - g_esa[i]) * k_ch + g_de[i+1] * (1 - k_ch);
      g_ci[i]   = g_de[i] != 0 ? (src - g_esa[i]) / (0.015 * g_de[i]) : 0;
      wt1Out[i] = g_ci[i] * k_av + wt1Out[i+1] * (1 - k_av);
   }

   // WT2 = SMA(WT1, WtMALen)
   for(int i = 0; i < size - WtMALen; i++)
   {
      double sum = 0;
      for(int j = i; j < i + WtMALen; j++) sum += wt1Out[j];
      wt2Out[i] = sum / WtMALen;
   }
}

//==========================================================================
//  GESTIÓN DE RIESGO - Cálculo de lotes
//==========================================================================
double CalcLots(double slPriceDistance)
{
   if(slPriceDistance <= 0) return 0;

   double equity    = AccountInfoDouble(ACCOUNT_EQUITY);
   double riskAmt   = equity * RISK_PERCENT * Leverage;
   if(riskAmt > MAX_LOSS_USD) riskAmt = MAX_LOSS_USD;

   double tickVal   = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double tickSz    = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
   if(tickVal <= 0 || tickSz <= 0) return 0;

   double lots = riskAmt / (slPriceDistance / tickSz * tickVal);

   double minLot  = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double maxLot  = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
   double lotStep = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
   lots = MathMax(minLot, MathMin(maxLot, MathRound(lots/lotStep)*lotStep));
   return lots;
}

//==========================================================================
//  3-STRIKES: Contar pérdidas diarias + aplicar reglas
//==========================================================================
void UpdateDailyLosses()
{
   MqlDateTime dt;
   TimeToStruct(TimeCurrent(), dt);
   datetime today = StringToTime(StringFormat("%04d.%02d.%02d 00:00:00",
                                               dt.year, dt.mon, dt.day));
   if(today != g_lastDay)
   {
      g_dailyLosses    = 0;
      g_tradingAllowed = true;
      g_lastDay        = today;
   }

   HistorySelect(today, TimeCurrent());
   int total  = HistoryDealsTotal();
   int losses = 0;
   for(int i = 0; i < total; i++)
   {
      ulong ticket = HistoryDealGetTicket(i);
      if(HistoryDealGetInteger(ticket, DEAL_MAGIC)  != MAGIC_NUMBER) continue;
      if(HistoryDealGetInteger(ticket, DEAL_ENTRY)  != DEAL_ENTRY_OUT) continue;
      double pnl = HistoryDealGetDouble(ticket, DEAL_PROFIT)
                 + HistoryDealGetDouble(ticket, DEAL_SWAP)
                 + HistoryDealGetDouble(ticket, DEAL_COMMISSION);
      if(pnl < 0) losses++;
   }
   g_dailyLosses = losses;
}

void ClosePosition(ulong ticket)
{
   MqlTradeRequest req = {}; MqlTradeResult res = {};
   req.action   = TRADE_ACTION_DEAL;
   req.symbol   = _Symbol;
   req.volume   = PositionGetDouble(POSITION_VOLUME);
   req.type     = ORDER_TYPE_SELL;
   req.price    = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   req.deviation= 30;
   req.magic    = MAGIC_NUMBER;
   req.position = ticket;
   OrderSend(req, res);
}

void MoveToBreakeven(ulong ticket, double entryPrice)
{
   MqlTradeRequest req = {}; MqlTradeResult res = {};
   req.action   = TRADE_ACTION_SLTP;
   req.symbol   = _Symbol;
   req.sl       = entryPrice;
   req.tp       = PositionGetDouble(POSITION_TP);
   req.position = ticket;
   OrderSend(req, res);
}

void ApplyStrikesRules()
{
   if(g_dailyLosses >= 3)
   {
      g_tradingAllowed = false;
      for(int i = PositionsTotal()-1; i >= 0; i--)
         if(PositionGetSymbol(i)==_Symbol && PositionGetInteger(POSITION_MAGIC)==MAGIC_NUMBER)
            ClosePosition(PositionGetInteger(POSITION_TICKET));
      return;
   }
   if(g_dailyLosses == 2)
   {
      g_tradingAllowed = false;
      for(int i = PositionsTotal()-1; i >= 0; i--)
      {
         if(PositionGetSymbol(i)!=_Symbol || PositionGetInteger(POSITION_MAGIC)!=MAGIC_NUMBER) continue;
         ulong  tk      = PositionGetInteger(POSITION_TICKET);
         double profit  = PositionGetDouble(POSITION_PROFIT);
         double entry   = PositionGetDouble(POSITION_PRICE_OPEN);
         if(profit >= 0) MoveToBreakeven(tk, entry);
         else            ClosePosition(tk);
      }
   }
}

//==========================================================================
//  DASHBOARD
//==========================================================================
void UpdateDashboard()
{
   double equity  = AccountInfoDouble(ACCOUNT_EQUITY);
   double riskUsd = equity * RISK_PERCENT * Leverage;
   if(riskUsd > MAX_LOSS_USD) riskUsd = MAX_LOSS_USD;

   string status  = g_tradingAllowed ? "✅ ACTIVO" : "🔴 BLOQUEADO (Drawdown)";
   string dash    = StringFormat(
      "╔══════════════════════════════╗\n"
      "║  %s - %s\n"
      "║  Estado Bot : %s\n"
      "║  Pérdidas Hoy: %d / 3\n"
      "║  Riesgo/Trade: $%.2f USD\n"
      "║  Apalancamiento: x%.1f\n"
      "║  Equity: $%.2f USD\n"
      "╚══════════════════════════════╝",
      EA_NAME, _Symbol,
      status,
      g_dailyLosses,
      riskUsd,
      Leverage,
      equity);
   Comment(dash);
}

//==========================================================================
//  EVENTOS PRINCIPALES
//==========================================================================
int OnInit()
{
   ArrayResize(g_wt1, g_bufSize);
   ArrayResize(g_wt2, g_bufSize);
   Print(EA_NAME, " inicializado. Magic=", MAGIC_NUMBER);
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason) { Comment(""); }

void OnTick()
{
   // Ejecutar solo en barra nueva
   static datetime lastBar = 0;
   datetime curBar = iTime(_Symbol, PERIOD_CURRENT, 0);
   if(curBar == lastBar) { UpdateDashboard(); return; }
   lastBar = curBar;

   // 1. Actualizar conteo de pérdidas
   UpdateDailyLosses();

   // 2. Aplicar reglas 3-strikes ANTES de lógica de entrada
   ApplyStrikesRules();

   // 3. Calcular WaveTrend
   int available = MathMin(g_bufSize, iBars(_Symbol, PERIOD_CURRENT));
   CalcWaveTrend(g_wt1, g_wt2, available);

   // 4. Señal de entrada: bar[1] para evitar repintado
   //    buySignal = cross(wt1, wt2) hacia arriba Y wt2 <= OsLevel
   bool wt_cross_up_1 = (g_wt1[1] >= g_wt2[1]) && (g_wt1[2] < g_wt2[2]);
   bool wt_oversold_1 = (g_wt2[1] <= OsLevel);
   bool buySignal     = wt_cross_up_1 && wt_oversold_1;

   // 5. Señal de salida (Red dot): cross hacia abajo en sobrecompra
   bool wt_cross_dn_1  = (g_wt1[1] <= g_wt2[1]) && (g_wt1[2] > g_wt2[2]);
   bool wt_overbought1 = (g_wt2[1] >= 53);
   bool redDot         = wt_cross_dn_1 && wt_overbought1;

   // 6. Cerrar posición si redDot
   if(redDot)
      for(int i = PositionsTotal()-1; i >= 0; i--)
         if(PositionGetSymbol(i)==_Symbol && PositionGetInteger(POSITION_MAGIC)==MAGIC_NUMBER)
            ClosePosition(PositionGetInteger(POSITION_TICKET));

   // 7. Abrir nueva posición si señal y trading permitido
   if(buySignal && g_tradingAllowed && PositionsTotal() == 0)
   {
      double ask     = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
      double slDist  = ask * (SL_Pct / 100.0);
      double tpDist  = ask * (TP_Pct / 100.0);
      double sl      = ask - slDist;
      double tp      = ask + tpDist;
      double lots    = CalcLots(slDist);
      if(lots <= 0) { UpdateDashboard(); return; }

      MqlTradeRequest req = {}; MqlTradeResult res = {};
      req.action    = TRADE_ACTION_DEAL;
      req.symbol    = _Symbol;
      req.volume    = lots;
      req.type      = ORDER_TYPE_BUY;
      req.price     = ask;
      req.sl        = NormalizeDouble(sl, _Digits);
      req.tp        = NormalizeDouble(tp, _Digits);
      req.deviation = 30;
      req.magic     = MAGIC_NUMBER;
      req.comment   = EA_NAME;
      if(!OrderSend(req, res))
         Print(EA_NAME, " Error al abrir: ", GetLastError());
   }

   UpdateDashboard();
}
//+------------------------------------------------------------------+

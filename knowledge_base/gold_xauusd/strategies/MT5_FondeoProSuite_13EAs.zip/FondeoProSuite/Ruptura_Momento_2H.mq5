//+------------------------------------------------------------------+
//|  Ruptura_Momento_2H.mq5                                          |
//|  Ruptura Momento PRO v3 - XAU/USD  |  Temporalidad: 2H   |
//|  Magic: 200004  |  Riesgo: 0.166% por trade                     |
//+------------------------------------------------------------------+
#property copyright "Fondeo Pro Suite"
#property version   "1.00"
#property strict

#define MAGIC_NUMBER   200004
#define EA_NAME        "Ruptura PRO 2H"

#define RISK_PERCENT   0.00166
#define MAX_LOSS_USD   170.0

//==========================================================================
//  PARÁMETROS EXTERNOS
//==========================================================================
input group "=== Indicadores Base ==="
input int    AdxLen        = 15;       // Periodos ADX
input int    AdxThresh     = 20;       // Umbral ADX
input int    DcLen         = 21;       // Periodos Donchian
input double StFactor      = 5.0;      // Factor SuperTrend
input int    StLen         = 17;       // Periodos SuperTrend

input group "=== Gestión de Riesgo ==="
input double RR_Ratio      = 2.2;      // Risk:Reward
input double MinRange      = 0.5;      // Filtro Rango Mínimo (%)

input group "=== Mejoras v3 ==="
input bool   UseSession    = true;     // Excluir sesión muerta (22:00-07:00 UTC)
input bool   UseRsiMin     = true;     // Filtro RSI mínimo
input int    RsiLen        = 14;       // Periodos RSI
input int    RsiFloor      = 45;       // RSI mínimo
input bool   UseFastDC     = true;     // Donchian Rápido
input int    DcFastLen     = 10;       // Periodos Donchian Rápido

input group "=== Riesgo ==="
input double Leverage      = 1.0;      // Apalancamiento (1-100)

//==========================================================================
//  VARIABLES GLOBALES
//==========================================================================
int      g_handleADX = INVALID_HANDLE;
int      g_handleST  = INVALID_HANDLE;
int      g_handleRSI = INVALID_HANDLE;

int      g_dailyLosses    = 0;
bool     g_tradingAllowed = true;
datetime g_lastDay        = 0;

//==========================================================================
//  SUPERTREND MANUAL
//==========================================================================
double g_stValue     = 0;
int    g_stDirection = 1; // 1=bajista precio, -1=alcista (Pine: <0 = bullish)

void CalcSuperTrend(double &stVal, int &stDir)
{
   // SuperTrend simplificado sobre barras cerradas
   int bars = MathMin(StLen * 4, iBars(_Symbol, PERIOD_CURRENT) - 1);
   if(bars < StLen + 2) return;

   double atr = 0;
   for(int i = 1; i <= StLen; i++)
   {
      double hi  = iHigh(_Symbol, PERIOD_CURRENT, i);
      double lo  = iLow (_Symbol, PERIOD_CURRENT, i);
      double pc  = iClose(_Symbol, PERIOD_CURRENT, i+1);
      double tr  = MathMax(hi-lo, MathMax(MathAbs(hi-pc), MathAbs(lo-pc)));
      atr += tr;
   }
   atr /= StLen;

   double hi1 = iHigh (_Symbol, PERIOD_CURRENT, 1);
   double lo1 = iLow  (_Symbol, PERIOD_CURRENT, 1);
   double hl2 = (hi1 + lo1) / 2.0;

   double upperBand = hl2 + StFactor * atr;
   double lowerBand = hl2 - StFactor * atr;
   double close1    = iClose(_Symbol, PERIOD_CURRENT, 1);

   // Determine trend direction
   if(close1 > upperBand)      { stDir = -1; stVal = lowerBand; } // Bullish
   else if(close1 < lowerBand) { stDir =  1; stVal = upperBand; } // Bearish
   else                         { stDir = g_stDirection; stVal = g_stValue; }
}

//==========================================================================
//  GESTIÓN DE RIESGO
//==========================================================================
double CalcLots(double slPriceDistance)
{
   if(slPriceDistance <= 0) return 0;
   double equity  = AccountInfoDouble(ACCOUNT_EQUITY);
   double riskAmt = equity * RISK_PERCENT * Leverage;
   if(riskAmt > MAX_LOSS_USD) riskAmt = MAX_LOSS_USD;

   double tickVal  = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double tickSz   = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
   if(tickVal <= 0 || tickSz <= 0) return 0;

   double lots = riskAmt / (slPriceDistance / tickSz * tickVal);
   double minL = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double maxL = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
   double step = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
   return MathMax(minL, MathMin(maxL, MathRound(lots/step)*step));
}

//==========================================================================
//  3-STRIKES
//==========================================================================
void UpdateDailyLosses()
{
   MqlDateTime dt; TimeToStruct(TimeCurrent(), dt);
   datetime today = StringToTime(StringFormat("%04d.%02d.%02d 00:00:00",
                                               dt.year, dt.mon, dt.day));
   if(today != g_lastDay) { g_dailyLosses=0; g_tradingAllowed=true; g_lastDay=today; }

   HistorySelect(today, TimeCurrent());
   int losses = 0;
   for(int i = 0; i < HistoryDealsTotal(); i++)
   {
      ulong tk = HistoryDealGetTicket(i);
      if(HistoryDealGetInteger(tk,DEAL_MAGIC) != MAGIC_NUMBER) continue;
      if(HistoryDealGetInteger(tk,DEAL_ENTRY) != DEAL_ENTRY_OUT) continue;
      double pnl = HistoryDealGetDouble(tk,DEAL_PROFIT)
                 + HistoryDealGetDouble(tk,DEAL_SWAP)
                 + HistoryDealGetDouble(tk,DEAL_COMMISSION);
      if(pnl < 0) losses++;
   }
   g_dailyLosses = losses;
}

void ClosePosition(ulong ticket)
{
   MqlTradeRequest req={}; MqlTradeResult res={};
   req.action=TRADE_ACTION_DEAL; req.symbol=_Symbol;
   req.volume=PositionGetDouble(POSITION_VOLUME);
   req.type=ORDER_TYPE_SELL;
   req.price=SymbolInfoDouble(_Symbol,SYMBOL_BID);
   req.deviation=30; req.magic=MAGIC_NUMBER; req.position=ticket;
   OrderSend(req,res);
}

void MoveToBreakeven(ulong ticket, double entryPrice)
{
   MqlTradeRequest req={}; MqlTradeResult res={};
   req.action=TRADE_ACTION_SLTP; req.symbol=_Symbol;
   req.sl=entryPrice; req.tp=PositionGetDouble(POSITION_TP); req.position=ticket;
   OrderSend(req,res);
}

void ApplyStrikesRules()
{
   if(g_dailyLosses >= 3)
   {
      g_tradingAllowed=false;
      for(int i=PositionsTotal()-1;i>=0;i--)
         if(PositionGetSymbol(i)==_Symbol && PositionGetInteger(POSITION_MAGIC)==MAGIC_NUMBER)
            ClosePosition(PositionGetInteger(POSITION_TICKET));
      return;
   }
   if(g_dailyLosses == 2)
   {
      g_tradingAllowed=false;
      for(int i=PositionsTotal()-1;i>=0;i--)
      {
         if(PositionGetSymbol(i)!=_Symbol || PositionGetInteger(POSITION_MAGIC)!=MAGIC_NUMBER) continue;
         ulong  tk     = PositionGetInteger(POSITION_TICKET);
         double profit = PositionGetDouble(POSITION_PROFIT);
         double entry  = PositionGetDouble(POSITION_PRICE_OPEN);
         if(profit >= 0) MoveToBreakeven(tk, entry);
         else            ClosePosition(tk);
      }
   }
}

//==========================================================================
//  DASHBOARD
//==========================================================================
void UpdateDashboard()
{
   double equity  = AccountInfoDouble(ACCOUNT_EQUITY);
   double riskUsd = MathMin(equity * RISK_PERCENT * Leverage, MAX_LOSS_USD);
   string status  = g_tradingAllowed ? "ACTIVO" : "BLOQUEADO (Drawdown)";
   Comment(StringFormat(
      "╔══════════════════════════════╗\n"
      "║  %s - %s\n"
      "║  Estado Bot : %s\n"
      "║  Perdidas Hoy: %d / 3\n"
      "║  Riesgo/Trade: $%.2f USD\n"
      "║  Apalancamiento: x%.1f\n"
      "║  Equity: $%.2f USD\n"
      "╚══════════════════════════════╝",
      EA_NAME, _Symbol, status,
      g_dailyLosses, riskUsd, Leverage, equity));
}

//==========================================================================
//  DONCHIAN CHANNEL
//==========================================================================
double DonchianHigh(int length, int shift=1)
{
   double hi = -DBL_MAX;
   for(int i=shift; i<shift+length; i++) hi=MathMax(hi, iHigh(_Symbol,PERIOD_CURRENT,i));
   return hi;
}

double DonchianLow(int length, int shift=1)
{
   double lo = DBL_MAX;
   for(int i=shift; i<shift+length; i++) lo=MathMin(lo, iLow(_Symbol,PERIOD_CURRENT,i));
   return lo;
}

//==========================================================================
//  EVENTOS PRINCIPALES
//==========================================================================
int OnInit()
{
   g_handleADX = iADX(_Symbol, PERIOD_CURRENT, AdxLen);
   g_handleRSI = iRSI(_Symbol, PERIOD_CURRENT, RsiLen, PRICE_CLOSE);
   if(g_handleADX==INVALID_HANDLE || g_handleRSI==INVALID_HANDLE)
   { Print(EA_NAME," Error creando handles"); return INIT_FAILED; }
   Print(EA_NAME, " inicializado. Magic=", MAGIC_NUMBER);
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   if(g_handleADX!=INVALID_HANDLE) IndicatorRelease(g_handleADX);
   if(g_handleRSI!=INVALID_HANDLE) IndicatorRelease(g_handleRSI);
   Comment("");
}

void OnTick()
{
   static datetime lastBar = 0;
   datetime curBar = iTime(_Symbol, PERIOD_CURRENT, 0);
   if(curBar == lastBar) { UpdateDashboard(); return; }
   lastBar = curBar;

   UpdateDailyLosses();
   ApplyStrikesRules();

   //--- Buffers ADX
   double adxBuf[3], diPlusBuf[3], diMinusBuf[3];
   if(CopyBuffer(g_handleADX, 0, 1, 3, adxBuf)    < 3) return;
   if(CopyBuffer(g_handleADX, 1, 1, 3, diPlusBuf)  < 3) return;
   if(CopyBuffer(g_handleADX, 2, 1, 3, diMinusBuf) < 3) return;

   double rsiArr[2];
   if(CopyBuffer(g_handleRSI, 0, 1, 2, rsiArr) < 2) return;

   //--- Calcular SuperTrend
   CalcSuperTrend(g_stValue, g_stDirection);

   //--- Valores actuales (bar 1 = última barra cerrada)
   double close1 = iClose(_Symbol, PERIOD_CURRENT, 1);
   double high1  = iHigh (_Symbol, PERIOD_CURRENT, 1);
   double close2 = iClose(_Symbol, PERIOD_CURRENT, 2);
   double adx1   = adxBuf[0];
   double rsi1   = rsiArr[0];

   //--- Donchian
   double upper_dc      = DonchianHigh(DcLen,  1);
   double lower_dc      = DonchianLow (DcLen,  1);
   double upper_dc_fast = DonchianHigh(DcFastLen, 1);
   double dc_midpoint   = lower_dc + (upper_dc - lower_dc) * 0.5;

   //--- Filtros
   bool range_ok   = (iHigh(_Symbol,PERIOD_CURRENT,1) - iLow(_Symbol,PERIOD_CURRENT,1))
                     / close1 > MinRange / 100.0;
   bool trend_long = g_stDirection < 0;  // Pine: st_direction < 0 = bullish
   bool momentum_ok= adx1 > AdxThresh;

   //--- Sesión UTC
   MqlDateTime dtNow; TimeToStruct(TimeGMT(), dtNow);
   bool in_session = !UseSession || (dtNow.hour >= 7 && dtNow.hour < 22);

   //--- RSI
   bool rsi_ok = !UseRsiMin || (rsi1 > RsiFloor);

   //--- Crossovers (bar[1] vs bar[2])
   bool cross_high_dc      = (high1 > upper_dc)      && (iHigh(_Symbol,PERIOD_CURRENT,2) <= upper_dc);
   bool cross_high_dc_fast = (high1 > upper_dc_fast) && (iHigh(_Symbol,PERIOD_CURRENT,2) <= upper_dc_fast);

   //--- Condiciones entrada
   bool breakout_long  = cross_high_dc;
   bool pullback_long  = (close1 > upper_dc) && (close2 < upper_dc) && trend_long;
   bool base_long      = range_ok && momentum_ok && trend_long && (breakout_long || pullback_long);

   bool fast_break_long = UseFastDC && cross_high_dc_fast && !cross_high_dc
                          && close1 > dc_midpoint && trend_long && momentum_ok && range_ok;

   bool long_cond = (base_long || fast_break_long) && in_session && rsi_ok;

   //--- Ejecución
   if(long_cond && g_tradingAllowed && PositionsTotal() == 0)
   {
      double ask    = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
      double slDist = MathAbs(ask - g_stValue);
      if(slDist <= 0) { UpdateDashboard(); return; }
      double tpDist = slDist * RR_Ratio;
      double sl     = NormalizeDouble(g_stValue, _Digits);
      double tp     = NormalizeDouble(ask + tpDist, _Digits);
      double lots   = CalcLots(slDist);
      if(lots <= 0) { UpdateDashboard(); return; }

      MqlTradeRequest req={}; MqlTradeResult res={};
      req.action=TRADE_ACTION_DEAL; req.symbol=_Symbol; req.volume=lots;
      req.type=ORDER_TYPE_BUY; req.price=ask;
      req.sl=sl; req.tp=tp; req.deviation=30;
      req.magic=MAGIC_NUMBER; req.comment=EA_NAME;
      if(!OrderSend(req,res)) Print(EA_NAME," Error: ",GetLastError());
   }

   //--- Trailing dinámico con SuperTrend
   for(int i=PositionsTotal()-1;i>=0;i--)
   {
      if(PositionGetSymbol(i)!=_Symbol || PositionGetInteger(POSITION_MAGIC)!=MAGIC_NUMBER) continue;
      ulong tk   = PositionGetInteger(POSITION_TICKET);
      double csl = PositionGetDouble(POSITION_SL);
      if(g_stValue > csl && g_stDirection < 0)
         MoveToBreakeven(tk, g_stValue); // Usa la función con nuevo SL
   }

   UpdateDashboard();
}
//+------------------------------------------------------------------+

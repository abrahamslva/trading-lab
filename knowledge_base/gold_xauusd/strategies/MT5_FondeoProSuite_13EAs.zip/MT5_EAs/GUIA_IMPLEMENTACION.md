# GUÍA DE IMPLEMENTACIÓN — MT5 EA Suite (13 Expert Advisors)
## Fondeo Pro Suite — XAU/USD

---

## ÍNDICE DE LOS 13 EAs

| # | Archivo | Estrategia | Temporalidad | Magic | Leverage Default |
|---|---------|-----------|--------------|-------|-----------------|
| 1 | VMC_B_LongOnly_1H.mq5 | VuManChu B Long Only | 1H | 100001 | 1x |
| 2 | VMC_B_LongOnly_2H.mq5 | VuManChu B Long Only | 2H | 100002 | 1x |
| 3 | VMC_B_LongOnly_3H.mq5 | VuManChu B Long Only | 3H | 100003 | 1x |
| 4 | VMC_B_LongOnly_4H.mq5 | VuManChu B Long Only | 4H | 100004 | 1x |
| 5 | Ruptura_Momento_5M.mq5 | Ruptura Momento PRO v3 | 5M | 200001 | 1x |
| 6 | Ruptura_Momento_15M.mq5 | Ruptura Momento PRO v3 | 15M | 200002 | 1x |
| 7 | Ruptura_Momento_1H.mq5 | Ruptura Momento PRO v3 | 1H | 200003 | 1x |
| 8 | Ruptura_Momento_2H.mq5 | Ruptura Momento PRO v3 | 2H | 200004 | 1x |
| 9 | Ruptura_Momento_3H.mq5 | Ruptura Momento PRO v3 | 3H | 200005 | 1x |
| 10 | Ruptura_Momento_4H.mq5 | Ruptura Momento PRO v3 | 4H | 200006 | 1x |
| 11 | MACD_Ribbon_1H.mq5 | MACD Bands + Ribbon | 1H | 300001 | 1x |
| 12 | MACD_Ribbon_2H.mq5 | MACD Bands + Ribbon | 2H | 300002 | **40x** |
| 13 | MACD_Ribbon_4H.mq5 | MACD Bands + Ribbon | 4H | 300003 | **25x** |

---

## PASO 1 — COPIAR ARCHIVOS AL DIRECTORIO CORRECTO

1. Abre MetaTrader 5
2. Menú: **Archivo → Abrir carpeta de datos**
3. Navega a: `MQL5/Experts/`
4. **Crea una subcarpeta** llamada `FondeoProSuite/`
5. Copia los **13 archivos `.mq5`** dentro de esa carpeta

---

## PASO 2 — COMPILAR EN MetaEditor

1. En MT5: menú **Herramientas → MetaEditor** (o F4)
2. En el árbol izquierdo: `Experts → FondeoProSuite`
3. Abre **cada archivo `.mq5`** y presiona **F7 (Compilar)**
4. ✅ Verifica que la barra inferior muestre **0 errores, 0 advertencias**
5. Repite para los 13 archivos

> **Nota:** Si aparece algún warning sobre `ArrayResize`, es normal en algunas versiones — no afecta la compilación ni ejecución.

---

## PASO 3 — ABRIR 13 GRÁFICOS EN MT5

Necesitas **13 ventanas de gráfico** simultáneas, una por EA:

| Símbolo | Temporalidad | EA a adjuntar |
|---------|-------------|---------------|
| XAUUSD | M5  | Ruptura_Momento_5M |
| XAUUSD | M15 | Ruptura_Momento_15M |
| XAUUSD | H1  | VMC_B_LongOnly_1H **+** Ruptura_Momento_1H **+** MACD_Ribbon_1H |
| XAUUSD | H2  | VMC_B_LongOnly_2H **+** Ruptura_Momento_2H **+** MACD_Ribbon_2H |
| XAUUSD | H3  | VMC_B_LongOnly_3H **+** Ruptura_Momento_3H |
| XAUUSD | H4  | VMC_B_LongOnly_4H **+** Ruptura_Momento_4H **+** MACD_Ribbon_4H |

> ⚠️ En MT5 **solo se puede ejecutar UN EA por gráfico**. Para timeframes que tienen múltiples EAs, debes abrir múltiples ventanas del mismo símbolo y temporalidad.

---

## PASO 4 — ADJUNTAR CADA EA AL GRÁFICO

1. Abre el gráfico correspondiente (Símbolo + Temporalidad)
2. En el Navegador izquierdo: `Experts → FondeoProSuite → [Nombre del EA]`
3. **Arrastra** el EA al gráfico (doble clic o drag & drop)
4. En la ventana de propiedades:
   - Tab **"Común"**: Activa ✅ **"Permitir trading automático"**
   - Tab **"Entradas"**: Configura los parámetros (ver sección siguiente)
5. Haz clic en **OK**
6. Verifica que aparezca la cara sonriente 🙂 en la esquina superior derecha del gráfico

---

## PASO 5 — CONFIGURACIÓN DE PARÁMETROS POR EA

### VMC B Long Only (4 EAs — Magic 100001 a 100004)
```
SL_Pct    = 1.0    (Stop Loss 1%)
TP_Pct    = 2.0    (Take Profit 2%)
Leverage  = 1.0    (ajustar según riesgo deseado)
```

### Ruptura Momento PRO v3 (6 EAs — Magic 200001 a 200006)
```
AdxThresh  = 20    (Fuerza de tendencia mínima)
StFactor   = 5.0   (Sensibilidad SuperTrend)
RR_Ratio   = 2.2   (Risk:Reward)
UseSession = true  (Excluye 22:00-07:00 UTC)
RsiFloor   = 45    (RSI mínimo para entrar)
Leverage   = 1.0   (ajustar según riesgo)
```

### MACD Bands + Ribbon (3 EAs — Magic 300001 a 300003)
```
MACD_1H: Leverage = 1.0   (sin apalancamiento extra)
MACD_2H: Leverage = 40.0  (según documento original)
MACD_4H: Leverage = 25.0  (según documento original)
SwingLen = 10  (velas para calcular el SL de mínimos)
```

---

## PASO 6 — VERIFICAR EL DASHBOARD

Una vez que el EA esté corriendo, verás en la esquina superior izquierda:
```
╔══════════════════════════════╗
║  MACD Ribbon 2H - XAUUSD
║  Estado Bot : ACTIVO
║  Perdidas Hoy: 0 / 3
║  Riesgo/Trade: $83.00 USD
║  Apalancamiento: x40.0
║  Equity: $50,000.00 USD
╚══════════════════════════════╝
```

---

## RESUMEN DE REGLAS DE RIESGO IMPLEMENTADAS

### Cálculo de Lotes
```
Lots = (Equity × 0.00166 × Leverage) / (SL_distancia × TickValue / TickSize)
Máximo de riesgo por trade: $170 USD (hardcoded)
```

### Protocolo 3-Strikes (se ejecuta en cada tick)
- **1ª pérdida:** Trading normal continúa
- **2ª pérdida:**
  - Posiciones en profit → SL movido a Break Even inmediatamente
  - Posiciones en pérdida → Cerradas a mercado inmediatamente
  - No se abren nuevos trades en el día
- **3ª pérdida (o después de la 2ª si no hay rescate):**
  - `TradingAllowed = false`
  - Todas las posiciones cerradas
  - El bot se reactiva automáticamente al inicio del siguiente día del servidor

### Reset diario
El contador se reinicia a medianoche (hora del servidor MT5), comprobando `TimeCurrent()`.

---

## RECOMENDACIONES PARA FONDEO

1. **Backtesting previo:** Antes de usar en cuenta real, corre el Strategy Tester con cada EA individualmente en el período 2023-2024 para verificar drawdown
2. **Cuenta demo:** Opera mínimo 2 semanas en demo con los 13 EAs activos simultáneamente
3. **VPS:** Usa un servidor VPS con MT5 para garantizar conexión 24/5 (recomendado: latencia < 10ms al broker)
4. **Capital base real:** El riesgo está calibrado para $50,000 USD. Si el capital es diferente, el cálculo de lotes se ajusta automáticamente vía `AccountInfoDouble(ACCOUNT_EQUITY)`
5. **Broker compatible fondeo:** Confirma que el broker permite EAs y tiene spread competitivo en XAUUSD (< 15 pips)

---

## TABLA DE MAGIC NUMBERS (no usar en otras estrategias)

```
100001 — VMC 1H        200001 — Ruptura 5M      300001 — MACD 1H
100002 — VMC 2H        200002 — Ruptura 15M     300002 — MACD 2H
100003 — VMC 3H        200003 — Ruptura 1H      300003 — MACD 4H
100004 — VMC 4H        200004 — Ruptura 2H
                       200005 — Ruptura 3H
                       200006 — Ruptura 4H
```

---

## SOLUCIÓN DE PROBLEMAS FRECUENTES

| Problema | Causa probable | Solución |
|----------|---------------|----------|
| Cara enojada 😠 en el gráfico | Trading automático deshabilitado | Botón "Algo Trading" en la barra superior |
| "0 errores" pero no opera | Spread demasiado alto | Verificar MaxSpread con el broker |
| Dashboard no aparece | EA no tiene permisos | Verificar pestaña "Común" al instalar |
| Lots = 0 en el log | SL demasiado pequeño o tickvalue=0 | Ajustar SL_Pct o verificar símbolo |
| Error 4756 al abrir trade | Fondos insuficientes | Verificar margen disponible |

---

*Generado por Fondeo Pro Suite — Todos los EAs operan exclusivamente Long en XAUUSD*
*Compatible con FTMO, The5ers, FundingPips y brokers regulados*

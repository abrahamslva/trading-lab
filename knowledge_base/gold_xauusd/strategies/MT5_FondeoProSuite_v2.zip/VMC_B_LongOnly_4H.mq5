//+------------------------------------------------------------------+
//|  VMC_B_LongOnly_4H.mq5                                          |
//|  VuManChu Cipher B Long Only | TF: 4H | Magic: 100004           |
//+------------------------------------------------------------------+
#property copyright "FondeoProSuite"
#property version   "2.00"

//--- IDs únicos
#define MAGIC_NUMBER  100004
#define EA_NAME       "VMC LongOnly 4H"
#define EA_TF         PERIOD_H4

//--- Riesgo institucional fijo
#define RISK_PCT      0.00166
#define MAX_RISK_USD  170.0
#define MAX_LOSS_DAY  510.0

//==========================================================================
// INPUTS
//==========================================================================
input group "== WaveTrend =="
input int    WtChLen   = 9;    // Canal WT
input int    WtAvgLen  = 12;   // Promedio WT
input int    WtMaLen   = 3;    // MA WT
input double OsLevel   = -53;  // Nivel Oversold

input group "== Estrategia =="
input double SL_Pct    = 1.0;  // Stop Loss %
input double TP_Pct    = 2.0;  // Take Profit %

input group "== Riesgo =="
input double Leverage  = 1.0;  // Apalancamiento

//==========================================================================
// GLOBALES
//==========================================================================
int      g_losses   = 0;
bool     g_allowed  = true;
datetime g_day      = 0;

// Buffers WaveTrend (200 barras históricas)
#define WT_BUF 300
double g_esa[WT_BUF], g_de[WT_BUF], g_ci[WT_BUF];
double g_wt1[WT_BUF], g_wt2[WT_BUF];

//==========================================================================
// WAVETREND  
//==========================================================================
void ComputeWT()
{
   int bars = (int)MathMin(WT_BUF, iBars(_Symbol, EA_TF) - 1);
   if(bars < WtChLen + WtAvgLen + WtMaLen + 10) return;

   double kCh = 2.0/(WtChLen+1), kAv = 2.0/(WtAvgLen+1);

   // Semilla: barra más antigua disponible
   int seed = bars - 1;
   double s0 = (iHigh(_Symbol,EA_TF,seed)+iLow(_Symbol,EA_TF,seed)+iClose(_Symbol,EA_TF,seed))/3.0;
   g_esa[seed] = s0; g_de[seed] = 1e-10; g_ci[seed] = 0; g_wt1[seed] = 0;

   // Construir de barras antiguas → recientes (índice alto → bajo)
   for(int i = seed-1; i >= 0; i--)
   {
      double hlc = (iHigh(_Symbol,EA_TF,i)+iLow(_Symbol,EA_TF,i)+iClose(_Symbol,EA_TF,i))/3.0;
      g_esa[i] = hlc*kCh + g_esa[i+1]*(1-kCh);
      double diff = MathAbs(hlc - g_esa[i]);
      g_de[i]  = diff*kCh + g_de[i+1]*(1-kCh);
      g_ci[i]  = g_de[i] > 1e-10 ? (hlc - g_esa[i])/(0.015*g_de[i]) : 0;
      g_wt1[i] = g_ci[i]*kAv + g_wt1[i+1]*(1-kAv);
   }

   // WT2 = SMA(WT1, WtMaLen)
   for(int i = 0; i <= seed - WtMaLen; i++)
   {
      double sum = 0;
      for(int j = i; j < i+WtMaLen; j++) sum += g_wt1[j];
      g_wt2[i] = sum/WtMaLen;
   }
}

//==========================================================================
// GESTIÓN DE RIESGO
//==========================================================================
double CalcLots(double slDist)
{
   if(slDist <= 0) return 0;
   double eq  = AccountInfoDouble(ACCOUNT_EQUITY);
   double risk = MathMin(eq * RISK_PCT * Leverage, MAX_RISK_USD);
   double tv   = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double ts   = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
   if(tv<=0||ts<=0) return 0;
   double lots = risk / (slDist/ts*tv);
   double mn=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN);
   double mx=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MAX);
   double st=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_STEP);
   return NormalizeDouble(MathMax(mn,MathMin(mx,MathRound(lots/st)*st)),2);
}

//==========================================================================
// 3-STRIKES
//==========================================================================
void CheckDailyReset()
{
   MqlDateTime d; TimeToStruct(TimeCurrent(),d);
   datetime today=StringToTime(StringFormat("%04d.%02d.%02d",d.year,d.mon,d.day));
   if(today!=g_day){g_losses=0;g_allowed=true;g_day=today;}
}

int CountDailyLosses()
{
   MqlDateTime d; TimeToStruct(TimeCurrent(),d);
   datetime today=StringToTime(StringFormat("%04d.%02d.%02d",d.year,d.mon,d.day));
   HistorySelect(today,TimeCurrent());
   int n=0;
   for(int i=0;i<HistoryDealsTotal();i++)
   {
      ulong tk=HistoryDealGetTicket(i);
      if(HistoryDealGetInteger(tk,DEAL_MAGIC)!=MAGIC_NUMBER) continue;
      if(HistoryDealGetInteger(tk,DEAL_ENTRY)!=DEAL_ENTRY_OUT) continue;
      double pnl=HistoryDealGetDouble(tk,DEAL_PROFIT)+HistoryDealGetDouble(tk,DEAL_SWAP)+HistoryDealGetDouble(tk,DEAL_COMMISSION);
      if(pnl<0) n++;
   }
   return n;
}

void ClosePos(ulong tk)
{
   if(!PositionSelectByTicket(tk)) return;
   MqlTradeRequest r={};MqlTradeResult s={};
   r.action=TRADE_ACTION_DEAL;r.symbol=_Symbol;
   r.volume=PositionGetDouble(POSITION_VOLUME);
   r.type=ORDER_TYPE_SELL;r.price=SymbolInfoDouble(_Symbol,SYMBOL_BID);
   r.deviation=50;r.magic=MAGIC_NUMBER;r.position=tk;
   OrderSend(r,s);
}

void SetBE(ulong tk)
{
   if(!PositionSelectByTicket(tk)) return;
   MqlTradeRequest r={};MqlTradeResult s={};
   r.action=TRADE_ACTION_SLTP;r.symbol=_Symbol;
   r.sl=PositionGetDouble(POSITION_PRICE_OPEN);
   r.tp=PositionGetDouble(POSITION_TP);r.position=tk;
   OrderSend(r,s);
}

void ApplyStrikes()
{
   g_losses=CountDailyLosses();
   if(g_losses>=3)
   {
      g_allowed=false;
      for(int i=PositionsTotal()-1;i>=0;i--)
         if(PositionGetSymbol(i)==_Symbol&&PositionGetInteger(POSITION_MAGIC)==MAGIC_NUMBER)
            ClosePos(PositionGetInteger(POSITION_TICKET));
      return;
   }
   if(g_losses==2)
   {
      g_allowed=false;
      for(int i=PositionsTotal()-1;i>=0;i--)
      {
         if(PositionGetSymbol(i)!=_Symbol||PositionGetInteger(POSITION_MAGIC)!=MAGIC_NUMBER) continue;
         ulong tk=PositionGetInteger(POSITION_TICKET);
         if(PositionGetDouble(POSITION_PROFIT)>=0) SetBE(tk);
         else ClosePos(tk);
      }
   }
}

//==========================================================================
// DASHBOARD
//==========================================================================
void Dashboard()
{
   double eq=AccountInfoDouble(ACCOUNT_EQUITY);
   double risk=MathMin(eq*RISK_PCT*Leverage,MAX_RISK_USD);
   string st=g_allowed?"✅ ACTIVO":"🔴 BLOQUEADO";
   Comment(StringFormat(
      "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
      " %s  |  %s\n"
      "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
      " Estado        : %s\n"
      " Pérdidas hoy  : %d / 3\n"
      " Riesgo/Trade  : $%.2f USD\n"
      " Apalancamiento: x%.1f\n"
      " Equity        : $%.2f\n"
      "━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
      EA_NAME,_Symbol,st,g_losses,risk,Leverage,eq));
}

//==========================================================================
// EVENTOS
//==========================================================================
int OnInit()
{
   Print("▶ ",EA_NAME," iniciado | Magic=",MAGIC_NUMBER," | Símbolo=",_Symbol);
   return INIT_SUCCEEDED;
}

void OnDeinit(const int r){Comment("");}

void OnTick()
{
   // Dashboard en cada tick para que siempre sea visible
   Dashboard();

   // Solo lógica en barra nueva cerrada
   static datetime lastBar=0;
   datetime curBar=iTime(_Symbol,EA_TF,0);
   if(curBar==lastBar) return;
   lastBar=curBar;

   CheckDailyReset();
   ApplyStrikes();

   // Calcular WaveTrend
   ComputeWT();

   // Señal en barra 1 (ya cerrada, sin repintado)
   // buySignal  = cruce wt1 cruza wt2 hacia arriba + oversold
   // sellSignal = cruce wt1 cruza wt2 hacia abajo  + overbought
   bool crossUp  = g_wt1[1]>=g_wt2[1] && g_wt1[2]<g_wt2[2];
   bool crossDn  = g_wt1[1]<=g_wt2[1] && g_wt1[2]>g_wt2[2];
   bool oversold = g_wt2[1] <= OsLevel;
   bool overbought=g_wt2[1] >= 53;

   bool buySignal = crossUp && oversold;
   bool redDot    = crossDn && overbought;

   // Cerrar por señal roja
   if(redDot)
      for(int i=PositionsTotal()-1;i>=0;i--)
         if(PositionGetSymbol(i)==_Symbol&&PositionGetInteger(POSITION_MAGIC)==MAGIC_NUMBER)
            ClosePos(PositionGetInteger(POSITION_TICKET));

   // Abrir long
   if(buySignal && g_allowed && PositionsTotal()==0)
   {
      double ask=SymbolInfoDouble(_Symbol,SYMBOL_ASK);
      double sl =NormalizeDouble(ask*(1-SL_Pct/100.0),_Digits);
      double tp =NormalizeDouble(ask*(1+TP_Pct/100.0),_Digits);
      double lot=CalcLots(ask-sl);
      if(lot<=0){Print(EA_NAME," lot=0, skip");return;}

      MqlTradeRequest r={};MqlTradeResult s={};
      r.action=TRADE_ACTION_DEAL;r.symbol=_Symbol;r.volume=lot;
      r.type=ORDER_TYPE_BUY;r.price=ask;
      r.sl=sl;r.tp=tp;r.deviation=50;
      r.magic=MAGIC_NUMBER;r.comment=EA_NAME;
      if(!OrderSend(r,s)) Print(EA_NAME," Error OrderSend: ",GetLastError());
      else Print(EA_NAME," Orden enviada | lots=",lot," SL=",sl," TP=",tp);
   }

   Dashboard(); // Actualizar tras lógica
}

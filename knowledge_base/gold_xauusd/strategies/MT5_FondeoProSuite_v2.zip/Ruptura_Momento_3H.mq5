//+------------------------------------------------------------------+
//|  Ruptura_Momento_3H.mq5                                          |
//|  Ruptura Momento PRO v3 | TF: 3H | Magic: 200005                |
//+------------------------------------------------------------------+
#property copyright "FondeoProSuite"
#property version   "2.00"

#define MAGIC_NUMBER  200005
#define EA_NAME       "Ruptura PRO 3H"
#define EA_TF         PERIOD_H3

#define RISK_PCT      0.00166
#define MAX_RISK_USD  170.0

//==========================================================================
// INPUTS
//==========================================================================
input group "== Indicadores =="
input int    AdxLen    = 15;    // Periodos ADX
input int    AdxThresh = 20;    // Umbral ADX
input int    DcLen     = 21;    // Donchian Principal
input double StFactor  = 5.0;   // Factor SuperTrend
input int    StLen     = 17;    // Periodos SuperTrend ATR

input group "== Gestión de Riesgo =="
input double RR        = 2.2;   // Risk:Reward
input double MinRange  = 0.5;   // Rango mínimo %

input group "== Mejoras v3 =="
input bool   UseSession= true;  // Filtrar sesión muerta 22-07 UTC
input bool   UseRsi    = true;  // Filtro RSI mínimo
input int    RsiLen    = 14;    // Periodos RSI
input int    RsiFloor  = 45;    // RSI mínimo
input bool   UseFastDC = true;  // Donchian rápido
input int    DcFastLen = 10;    // Donchian rápido periodos

input group "== Riesgo =="
input double Leverage  = 1.0;   // Apalancamiento

//==========================================================================
// GLOBALES
//==========================================================================
int      g_hADX, g_hRSI, g_hATR;
int      g_losses  = 0;
bool     g_allowed = true;
datetime g_day     = 0;

//==========================================================================
// SUPERTREND MANUAL (bullish cuando close > upper band)
//==========================================================================
bool SuperTrendBullish(double &stLevel)
{
   // ATR de las últimas StLen barras (barras cerradas)
   int bars = (int)MathMin(StLen*3+5, iBars(_Symbol,EA_TF)-2);
   if(bars < StLen+3){stLevel=0;return false;}

   // ATR simple
   double atrSum=0;
   for(int i=2;i<StLen+2;i++)
   {
      double h=iHigh(_Symbol,EA_TF,i), l=iLow(_Symbol,EA_TF,i), pc=iClose(_Symbol,EA_TF,i+1);
      atrSum+=MathMax(h-l, MathMax(MathAbs(h-pc), MathAbs(l-pc)));
   }
   double atr=atrSum/StLen;

   double h1=iHigh(_Symbol,EA_TF,1), l1=iLow(_Symbol,EA_TF,1), c1=iClose(_Symbol,EA_TF,1);
   double hl2=(h1+l1)/2.0;
   double upper=hl2+StFactor*atr;
   double lower=hl2-StFactor*atr;

   // Bullish = close > lowerBand, value = lowerBand (SL)
   if(c1>lower){stLevel=lower;return true;}
   stLevel=upper; return false;
}

//==========================================================================
// GESTIÓN DE RIESGO
//==========================================================================
double CalcLots(double slDist)
{
   if(slDist<=0) return 0;
   double eq=AccountInfoDouble(ACCOUNT_EQUITY);
   double risk=MathMin(eq*RISK_PCT*Leverage,MAX_RISK_USD);
   double tv=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_VALUE);
   double ts=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE);
   if(tv<=0||ts<=0) return 0;
   double lots=risk/(slDist/ts*tv);
   double mn=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN);
   double mx=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MAX);
   double st=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_STEP);
   return NormalizeDouble(MathMax(mn,MathMin(mx,MathRound(lots/st)*st)),2);
}

//==========================================================================
// 3-STRIKES
//==========================================================================
void CheckReset()
{
   MqlDateTime d;TimeToStruct(TimeCurrent(),d);
   datetime today=StringToTime(StringFormat("%04d.%02d.%02d",d.year,d.mon,d.day));
   if(today!=g_day){g_losses=0;g_allowed=true;g_day=today;}
}

void CountLosses()
{
   MqlDateTime d;TimeToStruct(TimeCurrent(),d);
   datetime today=StringToTime(StringFormat("%04d.%02d.%02d",d.year,d.mon,d.day));
   HistorySelect(today,TimeCurrent());
   int n=0;
   for(int i=0;i<HistoryDealsTotal();i++)
   {
      ulong tk=HistoryDealGetTicket(i);
      if(HistoryDealGetInteger(tk,DEAL_MAGIC)!=MAGIC_NUMBER) continue;
      if(HistoryDealGetInteger(tk,DEAL_ENTRY)!=DEAL_ENTRY_OUT) continue;
      double pnl=HistoryDealGetDouble(tk,DEAL_PROFIT)+HistoryDealGetDouble(tk,DEAL_SWAP)+HistoryDealGetDouble(tk,DEAL_COMMISSION);
      if(pnl<0) n++;
   }
   g_losses=n;
}

void ClosePos(ulong tk)
{
   if(!PositionSelectByTicket(tk)) return;
   MqlTradeRequest r={};MqlTradeResult s={};
   r.action=TRADE_ACTION_DEAL;r.symbol=_Symbol;
   r.volume=PositionGetDouble(POSITION_VOLUME);
   r.type=ORDER_TYPE_SELL;r.price=SymbolInfoDouble(_Symbol,SYMBOL_BID);
   r.deviation=50;r.magic=MAGIC_NUMBER;r.position=tk;
   OrderSend(r,s);
}

void SetSLTP(ulong tk,double sl,double tp)
{
   if(!PositionSelectByTicket(tk)) return;
   MqlTradeRequest r={};MqlTradeResult s={};
   r.action=TRADE_ACTION_SLTP;r.symbol=_Symbol;r.sl=sl;r.tp=tp;r.position=tk;
   OrderSend(r,s);
}

void ApplyStrikes()
{
   CountLosses();
   if(g_losses>=3)
   {
      g_allowed=false;
      for(int i=PositionsTotal()-1;i>=0;i--)
         if(PositionGetSymbol(i)==_Symbol&&PositionGetInteger(POSITION_MAGIC)==MAGIC_NUMBER)
            ClosePos(PositionGetInteger(POSITION_TICKET));
      return;
   }
   if(g_losses==2)
   {
      g_allowed=false;
      for(int i=PositionsTotal()-1;i>=0;i--)
      {
         if(PositionGetSymbol(i)!=_Symbol||PositionGetInteger(POSITION_MAGIC)!=MAGIC_NUMBER) continue;
         ulong tk=PositionGetInteger(POSITION_TICKET);
         double entry=PositionGetDouble(POSITION_PRICE_OPEN);
         double tp=PositionGetDouble(POSITION_TP);
         if(PositionGetDouble(POSITION_PROFIT)>=0) SetSLTP(tk,entry,tp);
         else ClosePos(tk);
      }
   }
}

//==========================================================================
// DASHBOARD
//==========================================================================
void Dashboard()
{
   double eq=AccountInfoDouble(ACCOUNT_EQUITY);
   double risk=MathMin(eq*RISK_PCT*Leverage,MAX_RISK_USD);
   string st=g_allowed?"✅ ACTIVO":"🔴 BLOQUEADO";
   Comment(StringFormat(
      "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
      " %s  |  %s\n"
      "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
      " Estado        : %s\n"
      " Pérdidas hoy  : %d / 3\n"
      " Riesgo/Trade  : $%.2f USD\n"
      " Apalancamiento: x%.1f\n"
      " Equity        : $%.2f\n"
      "━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
      EA_NAME,_Symbol,st,g_losses,risk,Leverage,eq));
}

//==========================================================================
// DONCHIAN
//==========================================================================
double DcHigh(int len,int shift=1)
{
   double hi=-DBL_MAX;
   for(int i=shift;i<shift+len;i++) hi=MathMax(hi,iHigh(_Symbol,EA_TF,i));
   return hi;
}
double DcLow(int len,int shift=1)
{
   double lo=DBL_MAX;
   for(int i=shift;i<shift+len;i++) lo=MathMin(lo,iLow(_Symbol,EA_TF,i));
   return lo;
}

//==========================================================================
// EVENTOS
//==========================================================================
int OnInit()
{
   g_hADX=iADX(_Symbol,EA_TF,AdxLen);
   g_hRSI=iRSI(_Symbol,EA_TF,RsiLen,PRICE_CLOSE);
   g_hATR=iATR(_Symbol,EA_TF,14);
   if(g_hADX==INVALID_HANDLE||g_hRSI==INVALID_HANDLE||g_hATR==INVALID_HANDLE)
   {Print(EA_NAME," INIT FAILED: handle inválido");return INIT_FAILED;}
   Print("▶ ",EA_NAME," OK | Magic=",MAGIC_NUMBER);
   return INIT_SUCCEEDED;
}

void OnDeinit(const int r)
{
   IndicatorRelease(g_hADX);
   IndicatorRelease(g_hRSI);
   IndicatorRelease(g_hATR);
   Comment("");
}

void OnTick()
{
   Dashboard();

   static datetime lastBar=0;
   datetime curBar=iTime(_Symbol,EA_TF,0);
   if(curBar==lastBar) return;
   lastBar=curBar;

   CheckReset();
   ApplyStrikes();

   //--- Leer indicadores (shift=1 = barra cerrada)
   double adxArr[3];
   if(CopyBuffer(g_hADX,0,1,3,adxArr)<3) return; // ADX principal

   double rsiArr[2];
   if(CopyBuffer(g_hRSI,0,1,2,rsiArr)<2) return;

   double adx1=adxArr[0], rsi1=rsiArr[0];

   //--- SuperTrend
   double stLevel=0;
   bool stBull=SuperTrendBullish(stLevel);

   //--- Donchian
   double upperDC  =DcHigh(DcLen,1);
   double lowerDC  =DcLow (DcLen,1);
   double upperFast=UseFastDC?DcHigh(DcFastLen,1):0;
   double midDC    =lowerDC+(upperDC-lowerDC)*0.5;

   double h1=iHigh (_Symbol,EA_TF,1);
   double h2=iHigh (_Symbol,EA_TF,2);
   double c1=iClose(_Symbol,EA_TF,1);
   double c2=iClose(_Symbol,EA_TF,2);

   //--- Filtros
   double range=(iHigh(_Symbol,EA_TF,1)-iLow(_Symbol,EA_TF,1))/c1;
   bool range_ok   =range>(MinRange/100.0);
   bool momentum_ok=adx1>AdxThresh;
   bool trend_long =stBull;

   MqlDateTime dn;TimeToStruct(TimeGMT(),dn);
   bool in_session=!UseSession||(dn.hour>=7&&dn.hour<22);
   bool rsi_ok    =!UseRsi||(rsi1>RsiFloor);

   //--- Crossovers (barra 1 vs barra 2)
   bool crossDC     =(h1>upperDC)  &&(h2<=upperDC);
   bool crossFast   =UseFastDC&&(h1>upperFast)&&(h2<=upperFast);
   bool pullback    =(c1>upperDC)&&(c2<=upperDC)&&trend_long;

   bool base_long  =range_ok&&momentum_ok&&trend_long&&(crossDC||pullback);
   bool fast_break =UseFastDC&&crossFast&&!crossDC&&c1>midDC&&trend_long&&momentum_ok&&range_ok;
   bool long_cond  =(base_long||fast_break)&&in_session&&rsi_ok;

   //--- Abrir posición
   if(long_cond&&g_allowed&&PositionsTotal()==0)
   {
      double ask=SymbolInfoDouble(_Symbol,SYMBOL_ASK);
      double slD=MathAbs(ask-stLevel);
      if(slD<=0||stLevel<=0) return;
      double sl =NormalizeDouble(stLevel,_Digits);
      double tp =NormalizeDouble(ask+slD*RR,_Digits);
      double lot=CalcLots(slD);
      if(lot<=0){Print(EA_NAME," lot=0");return;}

      MqlTradeRequest r={};MqlTradeResult s={};
      r.action=TRADE_ACTION_DEAL;r.symbol=_Symbol;r.volume=lot;
      r.type=ORDER_TYPE_BUY;r.price=ask;
      r.sl=sl;r.tp=tp;r.deviation=50;r.magic=MAGIC_NUMBER;r.comment=EA_NAME;
      if(!OrderSend(r,s)) Print(EA_NAME," Error: ",GetLastError());
      else Print(EA_NAME," Abierto | lot=",lot," SL=",sl," TP=",tp);
   }

   //--- Trailing SuperTrend
   for(int i=PositionsTotal()-1;i>=0;i--)
   {
      if(PositionGetSymbol(i)!=_Symbol||PositionGetInteger(POSITION_MAGIC)!=MAGIC_NUMBER) continue;
      ulong tk=PositionGetInteger(POSITION_TICKET);
      double csl=PositionGetDouble(POSITION_SL);
      double ctp=PositionGetDouble(POSITION_TP);
      if(stBull&&stLevel>csl&&stLevel>0)
         SetSLTP(tk,NormalizeDouble(stLevel,_Digits),ctp);
   }

   Dashboard();
}

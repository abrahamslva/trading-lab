//+------------------------------------------------------------------+
//|  MACD_Ribbon_2H.mq5                                             |
//|  MACD Bands + Ribbon FONDEO PRO | TF: 2H | Magic: 300002        |
//+------------------------------------------------------------------+
#property copyright "FondeoProSuite"
#property version   "2.00"

#define MAGIC_NUMBER  300002
#define EA_NAME       "MACD Ribbon 2H"
#define EA_TF         PERIOD_H2

#define RISK_PCT      0.00166
#define MAX_RISK_USD  170.0

//==========================================================================
// INPUTS
//==========================================================================
input group "== MACD =="
input int    FastLen   = 21;   // EMA Rápida
input int    SlowLen   = 35;   // EMA Lenta
input int    SignalLen = 14;   // EMA Señal

input group "== Ribbon =="
input int    RibbonLen = 14;   // EMA Ribbon
input int    RibbSmooth= 6;    // SMA Ribbon (suavizado)

input group "== Riesgo =="
input int    SwingLen  = 10;   // Velas para SL (mínimo swing)
input double Leverage  = 40.0;  // Apalancamiento

//==========================================================================
// GLOBALES
//==========================================================================
int      g_hFast, g_hSlow, g_hSignal, g_hRibbon, g_hATR;
int      g_losses  = 0;
bool     g_allowed = true;
datetime g_day     = 0;

//==========================================================================
// GESTIÓN DE RIESGO
//==========================================================================
double CalcLots(double slDist)
{
   if(slDist<=0) return 0;
   double eq=AccountInfoDouble(ACCOUNT_EQUITY);
   double risk=MathMin(eq*RISK_PCT*Leverage,MAX_RISK_USD);
   double tv=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_VALUE);
   double ts=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE);
   if(tv<=0||ts<=0) return 0;
   double lots=risk/(slDist/ts*tv);
   double mn=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN);
   double mx=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MAX);
   double st=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_STEP);
   return NormalizeDouble(MathMax(mn,MathMin(mx,MathRound(lots/st)*st)),2);
}

//==========================================================================
// 3-STRIKES
//==========================================================================
void CheckReset()
{
   MqlDateTime d;TimeToStruct(TimeCurrent(),d);
   datetime today=StringToTime(StringFormat("%04d.%02d.%02d",d.year,d.mon,d.day));
   if(today!=g_day){g_losses=0;g_allowed=true;g_day=today;}
}

void CountLosses()
{
   MqlDateTime d;TimeToStruct(TimeCurrent(),d);
   datetime today=StringToTime(StringFormat("%04d.%02d.%02d",d.year,d.mon,d.day));
   HistorySelect(today,TimeCurrent());
   int n=0;
   for(int i=0;i<HistoryDealsTotal();i++)
   {
      ulong tk=HistoryDealGetTicket(i);
      if(HistoryDealGetInteger(tk,DEAL_MAGIC)!=MAGIC_NUMBER) continue;
      if(HistoryDealGetInteger(tk,DEAL_ENTRY)!=DEAL_ENTRY_OUT) continue;
      double pnl=HistoryDealGetDouble(tk,DEAL_PROFIT)+HistoryDealGetDouble(tk,DEAL_SWAP)+HistoryDealGetDouble(tk,DEAL_COMMISSION);
      if(pnl<0) n++;
   }
   g_losses=n;
}

void ClosePos(ulong tk)
{
   if(!PositionSelectByTicket(tk)) return;
   MqlTradeRequest r={};MqlTradeResult s={};
   r.action=TRADE_ACTION_DEAL;r.symbol=_Symbol;
   r.volume=PositionGetDouble(POSITION_VOLUME);
   r.type=ORDER_TYPE_SELL;r.price=SymbolInfoDouble(_Symbol,SYMBOL_BID);
   r.deviation=50;r.magic=MAGIC_NUMBER;r.position=tk;
   OrderSend(r,s);
}

void SetSLTP(ulong tk,double sl,double tp)
{
   if(!PositionSelectByTicket(tk)) return;
   MqlTradeRequest r={};MqlTradeResult s={};
   r.action=TRADE_ACTION_SLTP;r.symbol=_Symbol;r.sl=sl;r.tp=tp;r.position=tk;
   OrderSend(r,s);
}

void ApplyStrikes()
{
   CountLosses();
   if(g_losses>=3)
   {
      g_allowed=false;
      for(int i=PositionsTotal()-1;i>=0;i--)
         if(PositionGetSymbol(i)==_Symbol&&PositionGetInteger(POSITION_MAGIC)==MAGIC_NUMBER)
            ClosePos(PositionGetInteger(POSITION_TICKET));
      return;
   }
   if(g_losses==2)
   {
      g_allowed=false;
      for(int i=PositionsTotal()-1;i>=0;i--)
      {
         if(PositionGetSymbol(i)!=_Symbol||PositionGetInteger(POSITION_MAGIC)!=MAGIC_NUMBER) continue;
         ulong tk=PositionGetInteger(POSITION_TICKET);
         double entry=PositionGetDouble(POSITION_PRICE_OPEN);
         double tp=PositionGetDouble(POSITION_TP);
         if(PositionGetDouble(POSITION_PROFIT)>=0) SetSLTP(tk,entry,tp);
         else ClosePos(tk);
      }
   }
}

//==========================================================================
// DASHBOARD
//==========================================================================
void Dashboard()
{
   double eq=AccountInfoDouble(ACCOUNT_EQUITY);
   double risk=MathMin(eq*RISK_PCT*Leverage,MAX_RISK_USD);
   string st=g_allowed?"✅ ACTIVO":"🔴 BLOQUEADO";
   Comment(StringFormat(
      "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
      " %s  |  %s\n"
      "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
      " Estado        : %s\n"
      " Pérdidas hoy  : %d / 3\n"
      " Riesgo/Trade  : $%.2f USD\n"
      " Apalancamiento: x%.1f\n"
      " Equity        : $%.2f\n"
      "━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
      EA_NAME,_Symbol,st,g_losses,risk,Leverage,eq));
}

//==========================================================================
// EVENTOS
//==========================================================================
int OnInit()
{
   // La señal MACD la computamos como EMA del MACD line directamente
   // g_hFast = EMA(close, FastLen)
   // g_hSlow = EMA(close, SlowLen)
   // MACD line = fast - slow  →  calculada manualmente con los dos handles
   // Signal    = EMA(MACD, SignalLen) →  usamos g_hSignal sobre close como proxy
   //   (En MQL5 no hay "handle de EMA de diferencia", así que usamos iMACD nativo)

   // iMACD(symbol, tf, fast, slow, signal, price)
   //   Buffer 0 = MACD line, Buffer 1 = Signal
   g_hFast  = iMACD(_Symbol,EA_TF,FastLen,SlowLen,SignalLen,PRICE_CLOSE);
   g_hRibbon= iMA  (_Symbol,EA_TF,RibbonLen,0,MODE_EMA,PRICE_CLOSE);
   g_hATR   = iATR (_Symbol,EA_TF,14);

   if(g_hFast==INVALID_HANDLE||g_hRibbon==INVALID_HANDLE||g_hATR==INVALID_HANDLE)
   {Print(EA_NAME," INIT FAILED");return INIT_FAILED;}

   Print("▶ ",EA_NAME," OK | Magic=",MAGIC_NUMBER);
   return INIT_SUCCEEDED;
}

void OnDeinit(const int r)
{
   IndicatorRelease(g_hFast);
   IndicatorRelease(g_hRibbon);
   IndicatorRelease(g_hATR);
   Comment("");
}

void OnTick()
{
   Dashboard();

   static datetime lastBar=0;
   datetime curBar=iTime(_Symbol,EA_TF,0);
   if(curBar==lastBar) return;
   lastBar=curBar;

   CheckReset();
   ApplyStrikes();

   //--- MACD: buffer 0=MACD line, buffer 1=Signal line
   //    Necesitamos barras 1 y 2 para detectar crossover
   double macdLine[3], signalLine[3];
   if(CopyBuffer(g_hFast,0,1,3,macdLine)  <3) return;
   if(CopyBuffer(g_hFast,1,1,3,signalLine)<3) return;

   // bull_dot = crossover(macdLine, signalLine)  en barra 1 vs 2
   bool bull_dot=(macdLine[0]>=signalLine[0])&&(macdLine[1]<signalLine[1]);

   //--- Ribbon: EMA(close, RibbonLen) y SMA del mismo
   double ribbonArr[10];
   int got=CopyBuffer(g_hRibbon,0,1,RibbSmooth,ribbonArr);
   if(got<RibbSmooth) return;
   double tr_base=ribbonArr[0]; // EMA más reciente (barra 1)
   double smoothSum=0;
   for(int i=0;i<RibbSmooth;i++) smoothSum+=ribbonArr[i];
   double tr_smooth=smoothSum/RibbSmooth;
   bool ribbon_green=tr_base>tr_smooth;

   //--- Estructura: close[1] > close[2]
   bool estructura=iClose(_Symbol,EA_TF,1)>iClose(_Symbol,EA_TF,2);

   //--- Filtro volatilidad: ATR[1] > SMA(ATR,20)
   double atrArr[22];
   if(CopyBuffer(g_hATR,0,1,22,atrArr)<22) return;
   double atrNow=atrArr[0];
   double atrSma=0;
   for(int i=0;i<20;i++) atrSma+=atrArr[i];
   atrSma/=20;
   bool filtro_vol=atrNow>atrSma;

   bool compra=bull_dot&&ribbon_green&&estructura&&filtro_vol;

   //--- Abrir posición
   if(compra&&g_allowed&&PositionsTotal()==0)
   {
      double ask=SymbolInfoDouble(_Symbol,SYMBOL_ASK);

      // SL = mínimo swing de SwingLen barras cerradas
      double sl_val=DBL_MAX;
      for(int i=1;i<=SwingLen;i++) sl_val=MathMin(sl_val,iLow(_Symbol,EA_TF,i));

      double riesgo=ask-sl_val;
      if(riesgo<=0) riesgo=atrNow;

      // RR dinámico
      double atr50=0;
      double atr50arr[52];
      if(CopyBuffer(g_hATR,0,1,52,atr50arr)>=52)
         for(int i=0;i<50;i++) atr50+=atr50arr[i]/50.0;
      double rr=atrNow>(atr50>0?atr50:atrNow*0.9)?1.8:1.3;
      double tp=NormalizeDouble(ask+riesgo*rr,_Digits);
      double sl=NormalizeDouble(sl_val,_Digits);
      double lot=CalcLots(riesgo);
      if(lot<=0){Print(EA_NAME," lot=0");return;}

      MqlTradeRequest r={};MqlTradeResult s={};
      r.action=TRADE_ACTION_DEAL;r.symbol=_Symbol;r.volume=lot;
      r.type=ORDER_TYPE_BUY;r.price=ask;
      r.sl=sl;r.tp=tp;r.deviation=50;r.magic=MAGIC_NUMBER;r.comment=EA_NAME;
      if(!OrderSend(r,s)) Print(EA_NAME," Error: ",GetLastError());
      else Print(EA_NAME," Abierto | lot=",lot," SL=",sl," TP=",tp);
   }

   //--- Break Even: si precio >= entry + riesgo inicial
   for(int i=PositionsTotal()-1;i>=0;i--)
   {
      if(PositionGetSymbol(i)!=_Symbol||PositionGetInteger(POSITION_MAGIC)!=MAGIC_NUMBER) continue;
      ulong tk=PositionGetInteger(POSITION_TICKET);
      double entry=PositionGetDouble(POSITION_PRICE_OPEN);
      double sl=PositionGetDouble(POSITION_SL);
      double tp=PositionGetDouble(POSITION_TP);
      double bid=SymbolInfoDouble(_Symbol,SYMBOL_BID);
      double riesgo_ini=entry-sl;
      if(riesgo_ini>0&&bid>=entry+riesgo_ini&&sl<entry)
         SetSLTP(tk,entry,tp);
   }

   Dashboard();
}

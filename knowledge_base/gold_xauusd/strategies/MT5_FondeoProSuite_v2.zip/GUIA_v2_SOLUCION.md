# GUÍA v2 — Solución al problema de la "carita" + Instalación correcta
## FondeoProSuite | 13 Expert Advisors MT5

---

## ❌ POR QUÉ NO APARECÍA LA CARITA SONRIENTE

El problema tenía DOS causas:

### Causa 1 — Código anterior tenía bugs de crash silencioso
El código calculaba el MACD de forma manual con arrays dinámicos que podían
fallar en el primer tick sin mostrar error visible. El EA se colgaba antes
de llegar al `Comment()`, por eso no aparecía nada en pantalla.

**Solución aplicada:** Reescritura completa usando `iMACD` nativo de MT5,
cero arrays manuales, y `Dashboard()` se llama antes de cualquier lógica.

### Causa 2 — Botón global "Algo Trading" desactivado
En MT5 existen DOS permisos separados:
- ✅ El que aceptas al arrastrar el EA (por EA)
- ✅ El botón verde de la barra superior (GLOBAL)

Ambos deben estar activos.

---

## PASO A PASO (desde cero, con archivos nuevos)

### 1. BORRAR EAs ANTERIORES

En MetaEditor o en el explorador de Windows:
- Navega a: `[MT5 Data Folder]\MQL5\Experts\FondeoProSuite\`
- **Elimina todos los archivos `.mq5` anteriores**
- Copia los 13 nuevos archivos `.mq5` en esa carpeta

Para encontrar la carpeta: MT5 → Archivo → Abrir carpeta de datos → MQL5 → Experts

### 2. COMPILAR (MetaEditor)

1. En MT5 presiona **F4** → abre MetaEditor
2. En el árbol izquierdo: Experts → FondeoProSuite
3. Abre cada `.mq5` y presiona **F7**
4. Resultado esperado: `0 errores, 0 advertencias`
5. Repite para los 13 archivos

### 3. ACTIVAR EL BOTÓN GLOBAL DE ALGO TRADING

**CRÍTICO — Este paso falla frecuentemente:**

En la barra de herramientas de MT5 busca el botón:
```
[ Algo Trading ]
```
Debe estar en color VERDE / activo.
Si está gris o apagado → haz clic en él para activarlo.

Alternativa: Menú → Herramientas → Opciones → Expert Advisors → 
marcar "Permitir trading automático"

### 4. ABRIR LOS GRÁFICOS CORRECTOS

Necesitas un gráfico por EA. Abre en MT5:

| Símbolo  | Temporalidad | EA                    |
|----------|--------------|-----------------------|
| XAUUSD   | M5           | Ruptura_Momento_5M    |
| XAUUSD   | M15          | Ruptura_Momento_15M   |
| XAUUSD   | H1           | VMC_B_LongOnly_1H     |
| XAUUSD   | H1           | Ruptura_Momento_1H    |
| XAUUSD   | H1           | MACD_Ribbon_1H        |
| XAUUSD   | H2           | VMC_B_LongOnly_2H     |
| XAUUSD   | H2           | Ruptura_Momento_2H    |
| XAUUSD   | H2           | MACD_Ribbon_2H (x40)  |
| XAUUSD   | H3           | VMC_B_LongOnly_3H     |
| XAUUSD   | H3           | Ruptura_Momento_3H    |
| XAUUSD   | H4           | VMC_B_LongOnly_4H     |
| XAUUSD   | H4           | Ruptura_Momento_4H    |
| XAUUSD   | H4           | MACD_Ribbon_4H (x25)  |

> ⚠️ Para la misma temporalidad con múltiples EAs, abre múltiples ventanas
> del mismo símbolo/temporalidad (MT5 lo permite).

### 5. ADJUNTAR CADA EA AL GRÁFICO

1. En el Navegador (izquierda): FondeoProSuite → [nombre del EA]
2. Doble clic o arrastra al gráfico
3. En la ventana que aparece:
   - Tab "Común": ✅ "Permitir trading automático"
   - Tab "Entradas": verificar parámetros
4. Clic OK
5. **Resultado esperado:** 
   - Carita sonriente 🙂 en esquina superior derecha
   - Panel de texto en esquina superior izquierda:
     ```
     ━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      MACD Ribbon 1H  |  XAUUSD
     ━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      Estado        : ✅ ACTIVO
      Pérdidas hoy  : 0 / 3
      Riesgo/Trade  : $83.00 USD
      Apalancamiento: x1.0
      Equity        : $50000.00
     ━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     ```

---

## SI AÚN NO APARECE LA CARITA

### Diagnóstico rápido:
1. Clic en la pestaña **"Expertos"** (abajo en MT5, junto a "Operaciones")
2. Busca mensajes de error del EA
3. Los mensajes comunes y sus soluciones:

| Mensaje en log "Expertos"               | Solución                         |
|-----------------------------------------|----------------------------------|
| `INIT FAILED: handle inválido`          | Símbolo incorrecto (usar XAUUSD) |
| `Error OrderSend: 10019`                | Fondos insuficientes             |
| `Error OrderSend: 10016`                | SL/TP muy cercano al precio      |
| `lot=0`                                 | Tick value = 0, cambiar broker   |
| (ningún mensaje)                        | Botón Algo Trading desactivado   |

### Para ver logs en tiempo real:
MT5 → Vista → Diario (o pestaña "Expertos" abajo)

---

## MAGIC NUMBERS — REFERENCIA RÁPIDA

```
VMC Long Only:      100001 (1H) · 100002 (2H) · 100003 (3H) · 100004 (4H)
Ruptura Momento:    200001 (5M) · 200002 (15M) · 200003 (1H) · 200004 (2H) · 200005 (3H) · 200006 (4H)
MACD + Ribbon:      300001 (1H) · 300002 (2H·x40) · 300003 (4H·x25)
```

---

## CAMBIOS EN CÓDIGO v2 vs v1

| Componente          | v1 (buggy)                        | v2 (corregido)                    |
|---------------------|-----------------------------------|-----------------------------------|
| MACD Signal         | Cálculo manual con loop EMA       | `iMACD` nativo (Buffer 1)         |
| WaveTrend           | Arrays dinámicos en OnTick        | Buffer estático WT_BUF=300        |
| Dashboard           | Solo en nueva barra               | Cada tick (siempre visible)       |
| Handles OnInit      | Sin falla graceful                | Retorna INIT_FAILED con Print     |
| SuperTrend          | Sin guard de barras               | Guard `bars < StLen+3`            |
| CopyBuffer          | Sin verificar valor retornado     | Todos los CopyBuffer verificados  |
